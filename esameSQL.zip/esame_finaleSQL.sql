use toysgroup;

-- Creazione della tabella Category
create table Category (
    Category_ID INT PRIMARY KEY,
    Category_Name VARCHAR(50) NOT NULL
);


-- Creazione della tabella Product
create table Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(50) NOT NULL,
    Category_ID INT,
    Each_Price DECIMAL(10,2),
    FOREIGN KEY (Category_ID) REFERENCES Category(Category_ID)
);


-- Creazione della tabella Region
create table Region (
    Region_ID INT PRIMARY KEY,
    Region_Name VARCHAR(50) NOT NULL
);


-- Creazione della tabella State
create table State (
    State_ID INT PRIMARY KEY,
    State_Name VARCHAR(50) NOT NULL,
    Region_ID INT,
    FOREIGN KEY (Region_ID) REFERENCES Region(Region_ID)
);



-- Creazione della tabella Sales
create table Sales (
    Sale_ID INT PRIMARY KEY,
    Product_ID INT,
    Region_ID INT,
    Sale_Date DATE,
    Quantity INT,
    Amount DECIMAL(10,2),
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    FOREIGN KEY (Region_ID) REFERENCES Region(Region_ID)
    );



-- Inserimento dati nella tabella Category
insert into Category (Category_ID, Category_Name) VALUES
(1, 'Puzzle'),
(2, 'Board Games'),
(3, 'Dolls');



-- Inserimento dati nella tabella Product
insert into Product (Product_ID, Product_Name, Category_ID, Each_Price) VALUES
(1, 'Savana', 1, '22.99'),
(2, 'Risiko', 2, '17.99'),
(3, 'Barbie', 3, '9.99'),
(4, 'Solar System', 1, '22.99'),
(5, 'Jenga', 2, '17.99'),
(6, 'Iron Man', 3, '9.99'),
(7, 'Pyramid', 1, '22.99'),
(8, 'Monopoli', 2, '17.99'),
(9, 'Landscape', 1, '22.99'),
(10, 'Hulk', 3, '9.99');



-- Inserimento dati nella tabella Region
insert into Region (Region_ID, Region_Name) VALUES
(1, 'North Europe'),
(2, 'West Europe'),
(3, 'South Europe'),
(4, 'East Europe');



-- Inserimento dati nella tabella State
insert into State (State_ID, State_Name, Region_ID) VALUES
(1, 'Finland', 1),
(2, 'Denmark', 1),
(3, 'Spain', 2),
(4, 'Germany', 2),
(5, 'Italy', 3),
(6, 'Bulgary', 4),
(7, 'Greece', 3),
(8, 'Portugal', 2);



-- Inserimento dati nella tabella Sales
insert into Sales (Sale_ID, Product_ID, Region_ID, Sale_Date, Quantity, Amount) VALUES
(1, 1, 2, '2024-02-19', 1, '22.99'),
(2, 2, 1, '2024-02-22', 1, '17.99'),
(3, 3, 4, '2024-02-21', 3, '29.97'),
(4, 4, 1, '2024-01-15', 1,  '22.99'),
(5, 5, 4, '2024-02-24', 4, '71.96'),
(6, 6, 3, '2024-02-18', 2, '19.98'),
(7, 7, 1, '2024-01-17', 1, '22.99'),
(8, 8, 2, '2024-02-16', 1, '17.99'),
(9, 9, 2, '2024-02-01', 0, '0.00'),
(10, 10, 3, '2024-02-15', 2, '18.98'),
(11, 1, 2, '2024-02-14', 1, '22.99'),
(12, 2, 4, '2024-01-5', 3, '53.97'),
(13, 3, 1, '2024-01-11', 1, '9.99'),
(14, 4, 2, '2024-01-30', 2, '45.98'),
(15, 5, 3, '2024-02-10', 2, '35.98'),
(16, 6, 1, '2024-01-3', 1, '9.99');


-- 1. Verificare che i campi definiti come PK siano univoci.
select Product_ID Id_Prodotto, COUNT(*)  Duplicati
from Product
group by Product_ID
having Duplicati > 1;


-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT p.Product_ID ID_Prodotto, p.Product_Name Nome_Prodotto, YEAR(s.Sale_Date) Anno, SUM(s.Amount) Fatturato_Totale
FROM Product p
JOIN Sales s using (Product_ID)
where s.Quantity <> 0
GROUP BY p.Product_ID, p.Product_Name, YEAR(s.Sale_Date);



-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
select distinct(st.State_Name) Nome_Stato, YEAR(s.Sale_Date) Anno, sum(s.Amount) Totale_Fatturato
from state st
join sales s using (Region_ID)
group by st.State_Name, year(s.Sale_Date)
order by YEAR(s.Sale_Date), sum(s.Amount) desc;



-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
 select c.Category_Name Nome_Categoria, sum(s.Quantity) Tot_Quantità
 from sales s
 join product p using (Product_ID)
 join category c using (Category_ID)
 group by Nome_Categoria
 order by Tot_Quantità desc
 limit 1;


-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- metodo 1
select p.Product_ID ID_Prodotto, p.Product_Name Nome_Prodotto, c.Category_Name Nome_Categoria, s.Quantity Quantità
from sales s
join product p using (Product_ID)
join category c using (Category_ID)
where s.Quantity = 0;

-- metodo 2
select p.Product_ID, p.Product_Name
from Product p
left join Sales s using (Product_ID)
where s.Sale_ID IS NULL;



-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
select p.Product_ID Id_Prodotto, p.Product_Name Nome_Prodotto, max(s.Sale_Date) Data_Vendita
from product p
join sales s using (Product_ID)
group by Id_Prodotto, Nome_Prodotto;



-- BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
-- la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, 
-- il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 
-- 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
select
    s.Sale_ID  Codice_Documento,
    s.Sale_Date Data_Vendita,
    p.Product_Name Nome_Prodotto,
    c.Category_Name Categoria_Prodotto,
    st.State_Name Nome_Stato,
    r.Region_Name Nome_Regione,
    case when DATEDIFF(CURDATE(), s.Sale_Date) > 180 THEN TRUE ELSE FALSE END Passati_180gg     -- son sincera, ho cercato su internet perchè non avevo idea di come si 
from Sales s                                                                                    -- inserisse un campo booleano
join product p using (Product_ID)
join category c using (Category_ID)
join region r using (Region_ID)
join state st using (Region_ID);